<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
    {{ $credit }}
</body>
</html>